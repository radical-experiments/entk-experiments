
  - For a list of bug fixes, see 
    https://github.com/radical-cybertools/radical.analytics/issues?q=is%3Aissue+is%3Aclosed+sort%3Aupdated-desc
  - For a list of open issues and known problems, see
    https://github.com/radical-cybertools/radical.analytics/issues?q=is%3Aissue+is%3Aopen+


0.45 Release                                                          2017-02-28
--------------------------------------------------------------------------------

  - clean out repository
  - sync branches 
  - sync version across radical stack 


0.1  Release                                                          2016-02-20
--------------------------------------------------------------------------------

  - initial release


--------------------------------------------------------------------------------

